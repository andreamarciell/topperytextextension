// Configure your backend here
// Example Netlify base (Functions): https://<site>.netlify.app/.netlify/functions/api
// Example Vercel base (Serverless): https://<project>.vercel.app/api
// NOTE: must support CORS for chrome-extension scheme.
const API_BASE = "https://topperytext.netlify.app/.netlify/functions/api"; // <-- change if needed
export default { API_BASE };
